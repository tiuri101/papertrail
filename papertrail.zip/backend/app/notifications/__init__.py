"""Asynchronous email notifications."""
