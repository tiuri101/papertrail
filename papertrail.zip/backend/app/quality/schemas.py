from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from app.forms.schemas import FieldResponse
from app.projects.models import TaskAllocationMode
from app.screening.schemas import PublicationItem


class ApiModel(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class QualityConfigUpdate(ApiModel):
    enabled: bool
    mode: str = "both"
    aggregation: str = "sum"
    allocation_mode: TaskAllocationMode = Field(
        default=TaskAllocationMode.CLAIM, alias="allocationMode"
    )


class QualityConfigResponse(ApiModel):
    enabled: bool
    mode: str
    aggregation: str
    allocation_mode: TaskAllocationMode = Field(serialization_alias="allocationMode")


class QualitySubmit(ApiModel):
    answers: dict[str, Any]


class QualityDraftUpdate(ApiModel):
    draft: dict[str, Any]


class QualityResponseModel(ApiModel):
    id: str
    answers: dict[str, Any]
    total_score: float | None = Field(serialization_alias="totalScore")
    version: int


class QualityItemResponse(ApiModel):
    id: str
    publication_id: str = Field(serialization_alias="publicationId")
    status: str
    draft: dict[str, Any]
    publication: PublicationItem
    fields: list[FieldResponse]
    current_response: QualityResponseModel | None = Field(
        default=None, serialization_alias="currentResponse"
    )


class CompletedQualitySummary(ApiModel):
    id: str
    publication_id: str = Field(serialization_alias="publicationId")
    publication: PublicationItem
    completed_at: datetime | None = Field(serialization_alias="completedAt")
    version: int
    total_score: float | None = Field(serialization_alias="totalScore")
