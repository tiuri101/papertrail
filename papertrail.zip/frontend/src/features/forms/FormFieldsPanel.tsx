import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useRef, useState } from 'react'

import { apiRequest } from '../../api/client'
import { ConfirmButton } from '../../components/ConfirmButton'
import { IconCheckCircle, IconDownload, IconPlus, IconTrash } from '../../components/icons'
import { InfoBox } from '../../components/InfoBox'
import { DynamicForm } from './DynamicForm'
import {
  buildScoring,
  describeRatingScale,
  fieldTypeLabels,
  fieldTypes,
  parseOptions,
  selectFieldTypes,
  weightedFieldTypes,
} from './fieldTypes'

type FormKind = 'extraction' | 'quality'

interface ReviewForm {
  id: string
  name: string
  kind: string
  isTemplate: boolean
  activeVersionId: string | null
}

interface FormField {
  id: string
  stableKey: string
  label: string
  fieldType: string
  required: boolean
  position: number
  isArchived: boolean
  options: string[]
  scoring: Record<string, unknown>
}

type TaskAllocationMode = 'pre_assigned' | 'claim'

const TASK_ALLOCATION_MODE_LABELS: Record<TaskAllocationMode, string> = {
  claim: 'Claim (reviewers pick up publications themselves)',
  pre_assigned: 'Pre-assigned (publications are split across reviewers)',
}

interface QualityConfig {
  enabled: boolean
  mode: string
  aggregation: string
  allocationMode: TaskAllocationMode
}

interface ExtractionConfig {
  allocationMode: TaskAllocationMode
}

export function FormFieldsPanel({
  projectId,
  kind,
  title,
  description,
}: {
  projectId: string
  kind: FormKind
  title: string
  description?: string
}) {
  const queryClient = useQueryClient()
  const isQualityForm = kind === 'quality'
  const [name, setName] = useState(kind === 'quality' ? 'Quality assessment form' : 'Extraction form')
  const [templateId, setTemplateId] = useState('')
  const [fieldLabel, setFieldLabel] = useState('')
  const [fieldType, setFieldType] = useState('long_text')
  const [required, setRequired] = useState(false)
  const [optionsText, setOptionsText] = useState('')
  const [ratingMin, setRatingMin] = useState('1')
  const [ratingMax, setRatingMax] = useState('5')
  const [weight, setWeight] = useState('')
  const [optionScores, setOptionScores] = useState<Record<string, string>>({})
  const [trueScore, setTrueScore] = useState('')
  const [falseScore, setFalseScore] = useState('')
  const [editingKey, setEditingKey] = useState<string | null>(null)
  const [editingLabel, setEditingLabel] = useState('')
  const [editingType, setEditingType] = useState('long_text')
  const [editingRequired, setEditingRequired] = useState(false)
  const [editingOptionsText, setEditingOptionsText] = useState('')
  const [editingRatingMin, setEditingRatingMin] = useState('1')
  const [editingRatingMax, setEditingRatingMax] = useState('5')
  const [editingWeight, setEditingWeight] = useState('')
  const [editingOptionScores, setEditingOptionScores] = useState<Record<string, string>>({})
  const [editingTrueScore, setEditingTrueScore] = useState('')
  const [editingFalseScore, setEditingFalseScore] = useState('')
  const [fieldOrder, setFieldOrder] = useState<string[]>([])
  const [previewAnswers, setPreviewAnswers] = useState<Record<string, unknown>>({})

  const [qcEnabled, setQcEnabled] = useState(false)
  const [qcMode, setQcMode] = useState('both')
  const [qcAggregation, setQcAggregation] = useState('sum')
  const [qcAllocationMode, setQcAllocationMode] = useState<TaskAllocationMode>('claim')
  const [extractionAllocationMode, setExtractionAllocationMode] = useState<TaskAllocationMode>('claim')

  const forms = useQuery({
    queryKey: ['forms', projectId],
    queryFn: () => apiRequest<ReviewForm[]>(`/api/v1/projects/${projectId}/forms`),
    enabled: Boolean(projectId),
  })
  const templates = useQuery({
    queryKey: ['form-templates'],
    queryFn: () => apiRequest<ReviewForm[]>('/api/v1/form-templates'),
    enabled: Boolean(projectId),
  })
  const existingForm = forms.data?.find((form) => !form.isTemplate && form.kind === kind)
  const fields = useQuery({
    queryKey: ['form-fields', existingForm?.id],
    queryFn: () => apiRequest<FormField[]>(`/api/v1/forms/${existingForm?.id}/fields`),
    enabled: Boolean(existingForm),
  })
  useEffect(() => {
    setFieldOrder(fields.data?.map((field) => field.stableKey) ?? [])
  }, [fields.data])
  const qualityConfig = useQuery({
    queryKey: ['quality-config', projectId],
    queryFn: () => apiRequest<QualityConfig>(`/api/v1/projects/${projectId}/quality-config`),
    enabled: Boolean(projectId) && isQualityForm,
  })
  const qualityConfigSeeded = useRef(false)
  useEffect(() => {
    if (qualityConfig.data && !qualityConfigSeeded.current) {
      qualityConfigSeeded.current = true
      setQcEnabled(qualityConfig.data.enabled ?? false)
      setQcMode(qualityConfig.data.mode ?? 'both')
      setQcAggregation(qualityConfig.data.aggregation ?? 'sum')
      setQcAllocationMode(qualityConfig.data.allocationMode ?? 'claim')
    }
  }, [qualityConfig.data])
  const extractionConfig = useQuery({
    queryKey: ['extraction-config', projectId],
    queryFn: () => apiRequest<ExtractionConfig>(`/api/v1/projects/${projectId}/extraction-config`),
    enabled: Boolean(projectId) && !isQualityForm,
  })
  const extractionConfigSeeded = useRef(false)
  useEffect(() => {
    if (extractionConfig.data && !extractionConfigSeeded.current) {
      extractionConfigSeeded.current = true
      setExtractionAllocationMode(extractionConfig.data.allocationMode ?? 'claim')
    }
  }, [extractionConfig.data])

  const templatesForKind = templates.data?.filter((template) => template.kind === kind) ?? []
  const showOptions = selectFieldTypes.has(fieldType)
  const showRatingScale = fieldType === 'rating'
  const options = parseOptions(optionsText)
  const ratingOptions = [ratingMin, ratingMax]

  const createForm = useMutation({
    mutationFn: () => apiRequest<ReviewForm>(`/api/v1/projects/${projectId}/forms`, {
      method: 'POST',
      body: JSON.stringify({ name, kind, templateId: templateId || undefined }),
    }),
    onSuccess: () => {
      setTemplateId('')
      queryClient.invalidateQueries({ queryKey: ['forms', projectId] })
    },
  })
  const addField = useMutation({
    mutationFn: () => apiRequest<FormField>(`/api/v1/forms/${existingForm?.id}/fields`, {
      method: 'POST',
      body: JSON.stringify({
        label: fieldLabel,
        fieldType,
        required,
        options: showOptions ? options : showRatingScale ? ratingOptions : [],
        scoring: buildScoring({ isQualityForm, fieldType, weight, options, optionScores, trueScore, falseScore }),
      }),
    }),
    onSuccess: () => {
      setFieldLabel('')
      setRequired(false)
      setOptionsText('')
      setRatingMin('1')
      setRatingMax('5')
      setWeight('')
      setOptionScores({})
      setTrueScore('')
      setFalseScore('')
      queryClient.invalidateQueries({ queryKey: ['form-fields', existingForm?.id] })
    },
  })
  const updateField = useMutation({
    mutationFn: (variables: {
      stableKey: string
      label: string
      fieldType: string
      required: boolean
      position: number
      options: string[]
      scoring: Record<string, unknown>
    }) => apiRequest<FormField>(
      `/api/v1/forms/${existingForm?.id}/fields/${variables.stableKey}`,
      {
        method: 'PATCH',
        body: JSON.stringify({
          label: variables.label,
          fieldType: variables.fieldType,
          required: variables.required,
          position: variables.position,
          options: variables.options,
          scoring: variables.scoring,
        }),
      },
    ),
    onSuccess: () => {
      setEditingKey(null)
      queryClient.invalidateQueries({ queryKey: ['form-fields', existingForm?.id] })
    },
  })
  const removeField = useMutation({
    mutationFn: (stableKey: string) => apiRequest<void>(
      `/api/v1/forms/${existingForm?.id}/fields/${stableKey}`,
      { method: 'DELETE' },
    ),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['form-fields', existingForm?.id] }),
  })
  const saveQualityConfig = useMutation({
    mutationFn: (next: QualityConfig) => apiRequest(
      `/api/v1/projects/${projectId}/quality-config`,
      { method: 'PUT', body: JSON.stringify(next) },
    ),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['quality-config', projectId] }),
  })
  const updateQualityConfig = (next: QualityConfig) => {
    setQcEnabled(next.enabled)
    setQcMode(next.mode)
    setQcAggregation(next.aggregation)
    setQcAllocationMode(next.allocationMode)
    if (qualityConfigSeeded.current) saveQualityConfig.mutate(next)
  }
  const saveExtractionConfig = useMutation({
    mutationFn: (next: ExtractionConfig) => apiRequest(
      `/api/v1/projects/${projectId}/extraction-config`,
      { method: 'PUT', body: JSON.stringify(next) },
    ),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['extraction-config', projectId] }),
  })
  const updateExtractionAllocationMode = (allocationMode: TaskAllocationMode) => {
    setExtractionAllocationMode(allocationMode)
    if (extractionConfigSeeded.current) saveExtractionConfig.mutate({ allocationMode })
  }

  const beginEditingField = (field: FormField) => {
    const scoring = field.scoring ?? {}
    const scoreValues = typeof scoring.values === 'object' && scoring.values !== null
      ? scoring.values as Record<string, unknown>
      : {}
    setEditingKey(field.stableKey)
    setEditingLabel(field.label)
    setEditingType(field.fieldType)
    setEditingRequired(field.required)
    setEditingOptionsText(field.options.join('\n'))
    setEditingRatingMin(field.options[0] ?? '1')
    setEditingRatingMax(field.options[1] ?? '5')
    setEditingWeight(scoring.weight == null ? '' : String(scoring.weight))
    setEditingOptionScores(Object.fromEntries(
      Object.entries(scoreValues).map(([option, score]) => [option, String(score)]),
    ))
    setEditingTrueScore(scoring.true == null ? '' : String(scoring.true))
    setEditingFalseScore(scoring.false == null ? '' : String(scoring.false))
  }

  const moveEditingField = (offset: -1 | 1) => {
    if (!editingKey) return
    setFieldOrder((current) => {
      const index = current.indexOf(editingKey)
      const target = index + offset
      if (index < 0 || target < 0 || target >= current.length) return current
      const next = [...current]
      ;[next[index], next[target]] = [next[target], next[index]]
      return next
    })
  }

  const orderedFields = [...(fields.data ?? [])].sort((left, right) => {
    const leftIndex = fieldOrder.indexOf(left.stableKey)
    const rightIndex = fieldOrder.indexOf(right.stableKey)
    return (leftIndex < 0 ? Number.MAX_SAFE_INTEGER : leftIndex)
      - (rightIndex < 0 ? Number.MAX_SAFE_INTEGER : rightIndex)
  })

  const mutationError = createForm.error ?? addField.error ?? updateField.error ?? removeField.error
  const activeFields = orderedFields.filter((field) => !field.isArchived)

  return (
    <section className="card">
      <h2>
        <span className="collapsible-section__title">
          <span className="collapsible-section__icon" aria-hidden="true">
            {isQualityForm ? <IconCheckCircle /> : <IconDownload />}
          </span>
          {title}
        </span>
      </h2>
      {description ? (
        <InfoBox icon={isQualityForm ? <IconCheckCircle /> : <IconDownload />}>
          <p>{description}</p>
        </InfoBox>
      ) : null}
      {forms.error ? <p className="error" role="alert">{forms.error.message}</p> : null}
      {mutationError ? <p className="error" role="alert">{mutationError.message}</p> : null}

      {isQualityForm ? (
        <div className="quality-settings-fields">
          <label>
            <input
              type="checkbox"
              checked={qcEnabled}
              onChange={(event) => updateQualityConfig({
                enabled: event.target.checked, mode: qcMode, aggregation: qcAggregation, allocationMode: qcAllocationMode,
              })}
            />
            Enable quality assessment
          </label>
          <div className="quality-settings-selects">
            <label>
              Mode
              <select
                value={qcMode}
                onChange={(event) => updateQualityConfig({
                  enabled: qcEnabled, mode: event.target.value, aggregation: qcAggregation, allocationMode: qcAllocationMode,
                })}
              >
                <option value="qualitative">Qualitative only</option>
                <option value="numeric">Numerical scoring only</option>
                <option value="both">Both</option>
              </select>
            </label>
            <label>
              Aggregation
              <select
                value={qcAggregation}
                onChange={(event) => updateQualityConfig({
                  enabled: qcEnabled, mode: qcMode, aggregation: event.target.value, allocationMode: qcAllocationMode,
                })}
              >
                <option value="sum">Simple sum</option>
                <option value="average">Average</option>
                <option value="weighted_average">Weighted average</option>
              </select>
            </label>
            <label>
              Allocation
              <select
                value={qcAllocationMode}
                onChange={(event) => updateQualityConfig({
                  enabled: qcEnabled, mode: qcMode, aggregation: qcAggregation,
                  allocationMode: event.target.value as TaskAllocationMode,
                })}
              >
                {(Object.keys(TASK_ALLOCATION_MODE_LABELS) as TaskAllocationMode[]).map((value) => (
                  <option key={value} value={value}>{TASK_ALLOCATION_MODE_LABELS[value]}</option>
                ))}
              </select>
            </label>
          </div>
          {saveQualityConfig.error ? <p className="error" role="alert">{saveQualityConfig.error.message}</p> : null}
          <p className="muted" aria-live="polite">
            {saveQualityConfig.isPending ? 'Saving…' : saveQualityConfig.isSuccess ? 'Saved.' : ' '}
          </p>
        </div>
      ) : (
        <div className="quality-settings-fields">
          <label>
            Allocation
            <select
              value={extractionAllocationMode}
              onChange={(event) => updateExtractionAllocationMode(event.target.value as TaskAllocationMode)}
            >
              {(Object.keys(TASK_ALLOCATION_MODE_LABELS) as TaskAllocationMode[]).map((value) => (
                <option key={value} value={value}>{TASK_ALLOCATION_MODE_LABELS[value]}</option>
              ))}
            </select>
          </label>
          {saveExtractionConfig.error ? <p className="error" role="alert">{saveExtractionConfig.error.message}</p> : null}
          <p className="muted" aria-live="polite">
            {saveExtractionConfig.isPending ? 'Saving…' : saveExtractionConfig.isSuccess ? 'Saved.' : ' '}
          </p>
        </div>
      )}

      {!existingForm ? (
        <form onSubmit={(event) => { event.preventDefault(); createForm.mutate() }}>
          <label>
            Name
            <input value={name} onChange={(event) => setName(event.target.value)} required />
          </label>
          <label>
            Start from template (optional)
            <select value={templateId} onChange={(event) => setTemplateId(event.target.value)}>
              <option value="">From scratch</option>
              {templatesForKind.map((template) => (
                <option key={template.id} value={template.id}>{template.name}</option>
              ))}
            </select>
          </label>
          {templates.error ? <p className="error" role="alert">{templates.error.message}</p> : null}
          <button type="submit" disabled={createForm.isPending}>
            <IconPlus />
            Create {isQualityForm ? 'Quality' : 'Extraction'} Form
          </button>
        </form>
      ) : (
        <>
          <h3>Add Field</h3>
          <form onSubmit={(event) => { event.preventDefault(); addField.mutate() }}>
            <label>
              Label
              <input value={fieldLabel} onChange={(event) => setFieldLabel(event.target.value)} required />
            </label>
            <label>
              Type
              <select value={fieldType} onChange={(event) => setFieldType(event.target.value)}>
                {fieldTypes.map((type) => (
                  <option key={type} value={type}>{fieldTypeLabels[type] ?? type}</option>
                ))}
              </select>
            </label>
            <label>
              <input
                type="checkbox"
                checked={required}
                onChange={(event) => setRequired(event.target.checked)}
              />
              Required
            </label>
            {showOptions ? (
              <label>
                Options (one per line)
                <textarea
                  value={optionsText}
                  onChange={(event) => setOptionsText(event.target.value)}
                  rows={4}
                />
              </label>
            ) : null}
            {showRatingScale ? (
              <>
                <label>
                  Scale minimum
                  <input type="number" value={ratingMin} onChange={(event) => setRatingMin(event.target.value)} />
                </label>
                <label>
                  Scale maximum
                  <input type="number" value={ratingMax} onChange={(event) => setRatingMax(event.target.value)} />
                </label>
              </>
            ) : null}
            {isQualityForm && weightedFieldTypes.has(fieldType) ? (
              <label>
                Score weight
                <input type="number" value={weight} onChange={(event) => setWeight(event.target.value)} />
              </label>
            ) : null}
            {isQualityForm && fieldType === 'single_select' ? (
              <fieldset>
                <legend>Score per option</legend>
                {options.length === 0 ? <p className="muted">Add options above first.</p> : null}
                {options.map((option) => (
                  <label key={option}>
                    {option}
                    <input
                      type="number"
                      value={optionScores[option] ?? ''}
                      onChange={(event) => setOptionScores((current) => ({ ...current, [option]: event.target.value }))}
                    />
                  </label>
                ))}
              </fieldset>
            ) : null}
            {isQualityForm && fieldType === 'checkbox' ? (
              <>
                <label>
                  Score if checked
                  <input type="number" value={trueScore} onChange={(event) => setTrueScore(event.target.value)} />
                </label>
                <label>
                  Score if unchecked
                  <input type="number" value={falseScore} onChange={(event) => setFalseScore(event.target.value)} />
                </label>
              </>
            ) : null}
            <button type="submit" disabled={addField.isPending}><IconPlus />Add Field</button>
          </form>

          <h3>Fields</h3>
          {fields.error ? <p className="error" role="alert">{fields.error.message}</p> : null}
          {activeFields.length === 0 ? <p className="muted">No fields added yet.</p> : (
            <div className="llm-schema-fields form-editor-fields">
              {activeFields.map((field) => {
                const editingOptions = parseOptions(editingOptionsText)
                const editingIndex = fieldOrder.indexOf(field.stableKey)
                return (
                  <details
                    className="llm-schema-field form-editor-field"
                    key={field.id}
                    open={editingKey === field.stableKey}
                  >
                    <summary
                      className="llm-schema-field__summary"
                      onClick={(event) => {
                        event.preventDefault()
                        if (editingKey !== field.stableKey) beginEditingField(field)
                      }}
                    >
                      <span className="llm-schema-field__title">
                        <strong>{field.label}</strong>
                        <span className="status-badge">
                          {fieldTypeLabels[field.fieldType] ?? field.fieldType}
                          {field.fieldType === 'rating' ? ` (${describeRatingScale(field.options)})` : ''}
                        </span>
                        {field.required ? <span className="status-badge">Required</span> : null}
                      </span>
                      <span className="llm-schema-field__mapping">
                        {field.required ? 'Reviewers must complete this field' : 'Optional for reviewers'}
                      </span>
                      <span className="llm-schema-field__preview">
                        {field.fieldType === 'rating'
                          ? `Rating scale ${describeRatingScale(field.options)}`
                          : selectFieldTypes.has(field.fieldType)
                            ? field.options.length ? `Options: ${field.options.join(', ')}` : 'No options configured.'
                            : `${fieldTypeLabels[field.fieldType] ?? field.fieldType} response field`}
                      </span>
                    </summary>
                    <div className="llm-schema-field__content">
                      {editingKey === field.stableKey ? (
                        <>
                          <label>
                            Label
                            <input
                              aria-label={`Edit label for ${field.label}`}
                              value={editingLabel}
                              onChange={(event) => setEditingLabel(event.target.value)}
                            />
                          </label>
                          <label>
                            Type
                            <select
                              aria-label={`Edit type for ${field.label}`}
                              value={editingType}
                              onChange={(event) => setEditingType(event.target.value)}
                            >
                              {fieldTypes.map((type) => (
                                <option key={type} value={type}>{fieldTypeLabels[type] ?? type}</option>
                              ))}
                            </select>
                          </label>
                          <label>
                            <input
                              type="checkbox"
                              aria-label={`Edit required for ${field.label}`}
                              checked={editingRequired}
                              onChange={(event) => setEditingRequired(event.target.checked)}
                            />
                            Required
                          </label>
                          {selectFieldTypes.has(editingType) ? (
                            <label>
                              Options (one per line)
                              <textarea
                                aria-label={`Edit options for ${field.label}`}
                                value={editingOptionsText}
                                onChange={(event) => setEditingOptionsText(event.target.value)}
                                rows={4}
                              />
                            </label>
                          ) : null}
                          {editingType === 'rating' ? (
                            <div className="form-editor-field__settings-row">
                              <label>
                                Scale minimum
                                <input
                                  type="number"
                                  aria-label={`Edit scale minimum for ${field.label}`}
                                  value={editingRatingMin}
                                  onChange={(event) => setEditingRatingMin(event.target.value)}
                                />
                              </label>
                              <label>
                                Scale maximum
                                <input
                                  type="number"
                                  aria-label={`Edit scale maximum for ${field.label}`}
                                  value={editingRatingMax}
                                  onChange={(event) => setEditingRatingMax(event.target.value)}
                                />
                              </label>
                            </div>
                          ) : null}
                          {isQualityForm && weightedFieldTypes.has(editingType) ? (
                            <label>
                              Score weight
                              <input
                                type="number"
                                aria-label={`Edit score weight for ${field.label}`}
                                value={editingWeight}
                                onChange={(event) => setEditingWeight(event.target.value)}
                              />
                            </label>
                          ) : null}
                          {isQualityForm && editingType === 'single_select' ? (
                            <fieldset>
                              <legend>Score per option</legend>
                              {editingOptions.length === 0 ? <p className="muted">Add options above first.</p> : null}
                              {editingOptions.map((option) => (
                                <label key={option}>
                                  {option}
                                  <input
                                    type="number"
                                    aria-label={`Edit score for ${option}`}
                                    value={editingOptionScores[option] ?? ''}
                                    onChange={(event) => setEditingOptionScores((current) => ({
                                      ...current,
                                      [option]: event.target.value,
                                    }))}
                                  />
                                </label>
                              ))}
                            </fieldset>
                          ) : null}
                          {isQualityForm && editingType === 'checkbox' ? (
                            <div className="form-editor-field__settings-row">
                              <label>
                                Score if checked
                                <input
                                  type="number"
                                  aria-label={`Edit checked score for ${field.label}`}
                                  value={editingTrueScore}
                                  onChange={(event) => setEditingTrueScore(event.target.value)}
                                />
                              </label>
                              <label>
                                Score if unchecked
                                <input
                                  type="number"
                                  aria-label={`Edit unchecked score for ${field.label}`}
                                  value={editingFalseScore}
                                  onChange={(event) => setEditingFalseScore(event.target.value)}
                                />
                              </label>
                            </div>
                          ) : null}
                          <div className="toolbar">
                            <button
                              type="button"
                              className="button-secondary"
                              disabled={editingIndex <= 0}
                              onClick={() => moveEditingField(-1)}
                            >
                              Move Up
                            </button>
                            <button
                              type="button"
                              className="button-secondary"
                              disabled={editingIndex < 0 || editingIndex === fieldOrder.length - 1}
                              onClick={() => moveEditingField(1)}
                            >
                              Move Down
                            </button>
                            <button
                              type="button"
                              disabled={updateField.isPending}
                              onClick={() => {
                                const nextOptions = selectFieldTypes.has(editingType)
                                  ? editingOptions
                                  : editingType === 'rating' ? [editingRatingMin, editingRatingMax] : []
                                updateField.mutate({
                                  stableKey: field.stableKey,
                                  label: editingLabel,
                                  fieldType: editingType,
                                  required: editingRequired,
                                  position: fieldOrder.indexOf(field.stableKey),
                                  options: nextOptions,
                                  scoring: buildScoring({
                                    isQualityForm,
                                    fieldType: editingType,
                                    weight: editingWeight,
                                    options: nextOptions,
                                    optionScores: editingOptionScores,
                                    trueScore: editingTrueScore,
                                    falseScore: editingFalseScore,
                                  }),
                                })
                              }}
                            >
                              <IconCheckCircle />
                              Save
                            </button>
                            <button
                              type="button"
                              className="button-secondary"
                              onClick={() => {
                                setEditingKey(null)
                                setFieldOrder(fields.data?.map((item) => item.stableKey) ?? [])
                              }}
                            >
                              Cancel
                            </button>
                          </div>
                          <ConfirmButton
                            label="Remove"
                            confirmLabel="Remove Field"
                            warning={`Remove field "${field.label}"? This can't be undone.`}
                            onConfirm={() => removeField.mutate(field.stableKey)}
                            disabled={removeField.isPending}
                            variant="danger"
                            icon={<IconTrash />}
                          />
                        </>
                      ) : null}
                    </div>
                  </details>
                )
              })}
            </div>
          )}

          {activeFields.length ? (
            <>
              <h3>Preview</h3>
              <div className="card">
                <DynamicForm
                  fields={activeFields.map((field) => ({
                    stableKey: field.stableKey,
                    label: field.label,
                    fieldType: field.fieldType,
                    required: field.required,
                    options: field.options,
                  }))}
                  value={previewAnswers}
                  onChange={(key, value) => setPreviewAnswers((current) => ({ ...current, [key]: value }))}
                />
              </div>
            </>
          ) : null}
        </>
      )}
    </section>
  )
}
